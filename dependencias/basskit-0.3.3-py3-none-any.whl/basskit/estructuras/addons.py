# -*- coding: utf-8 -*-
"""Estructuras ctypes de todos los add-ons de BASS."""

import ctypes


# ─── BASS_FX ─────────────────────────────────────────────────────────

class BASS_BFX_ECHO(ctypes.Structure):
	"""Eco simple."""
	_fields_ = [("fLevel", ctypes.c_float), ("lDelay", ctypes.c_int)]

class BASS_BFX_FLANGER(ctypes.Structure):
	"""Flanger."""
	_fields_ = [("fWetDry", ctypes.c_float), ("fSpeed", ctypes.c_float), ("lChannel", ctypes.c_int)]

class BASS_BFX_VOLUME(ctypes.Structure):
	"""Control de volumen por canal."""
	_fields_ = [("lChannel", ctypes.c_int), ("fVolume", ctypes.c_float)]

class BASS_BFX_PEAKEQ(ctypes.Structure):
	"""Ecualizador parametrico."""
	_fields_ = [
		("lBand", ctypes.c_int), ("fBandwidth", ctypes.c_float),
		("fQ", ctypes.c_float), ("fCenter", ctypes.c_float),
		("fGain", ctypes.c_float), ("lChannel", ctypes.c_float),
	]

class BASS_BFX_REVERB(ctypes.Structure):
	"""Reverberacion."""
	_fields_ = [("fLevel", ctypes.c_float), ("lDelay", ctypes.c_int)]

class BASS_BFX_LPF(ctypes.Structure):
	"""Filtro paso bajo."""
	_fields_ = [("fResonance", ctypes.c_float), ("fCutOffFreq", ctypes.c_float), ("lChannel", ctypes.c_int)]

class BASS_BFX_MIX(ctypes.Structure):
	"""Mezcla/swap de canales."""
	_fields_ = [("lChannel", ctypes.c_int)]

class BASS_BFX_DAMP(ctypes.Structure):
	"""Amplificacion dinamica."""
	_fields_ = [
		("fTarget", ctypes.c_float), ("fQuiet", ctypes.c_float),
		("fRate", ctypes.c_float), ("fGain", ctypes.c_float),
		("fDelay", ctypes.c_float), ("lChannel", ctypes.c_int),
	]

class BASS_BFX_AUTOWAH(ctypes.Structure):
	"""Auto wah."""
	_fields_ = [
		("fDryMix", ctypes.c_float), ("fWetMix", ctypes.c_float),
		("fFeedback", ctypes.c_float), ("fRate", ctypes.c_float),
		("fRange", ctypes.c_float), ("fFreq", ctypes.c_float),
		("lChannel", ctypes.c_int),
	]

class BASS_BFX_ECHO2(ctypes.Structure):
	"""Eco 2."""
	_fields_ = [
		("fDryMix", ctypes.c_float), ("fWetMix", ctypes.c_float),
		("fFeedback", ctypes.c_float), ("fDelay", ctypes.c_float),
		("lChannel", ctypes.c_int),
	]

class BASS_BFX_PHASER(ctypes.Structure):
	"""Phaser."""
	_fields_ = [
		("fDryMix", ctypes.c_float), ("fWetMix", ctypes.c_float),
		("fFeedback", ctypes.c_float), ("fRate", ctypes.c_float),
		("fRange", ctypes.c_float), ("fFreq", ctypes.c_float),
		("lChannel", ctypes.c_int),
	]

class BASS_BFX_ECHO3(ctypes.Structure):
	"""Eco 3."""
	_fields_ = [
		("fDryMix", ctypes.c_float), ("fWetMix", ctypes.c_float),
		("fDelay", ctypes.c_float), ("lChannel", ctypes.c_int),
	]

class BASS_BFX_CHORUS(ctypes.Structure):
	"""Chorus."""
	_fields_ = [
		("fDryMix", ctypes.c_float), ("fWetMix", ctypes.c_float),
		("fFeedback", ctypes.c_float), ("fMinSweep", ctypes.c_float),
		("fMaxSweep", ctypes.c_float), ("fRate", ctypes.c_float),
		("lChannel", ctypes.c_int),
	]

class BASS_BFX_APF(ctypes.Structure):
	"""Filtro pasa-todo."""
	_fields_ = [("fGain", ctypes.c_float), ("fDelay", ctypes.c_float), ("lChannel", ctypes.c_int)]

class BASS_BFX_COMPRESSOR(ctypes.Structure):
	"""Compresor."""
	_fields_ = [
		("fThreshold", ctypes.c_float), ("fAttacktime", ctypes.c_float),
		("fReleasetime", ctypes.c_float), ("lChannel", ctypes.c_int),
	]

class BASS_BFX_DISTORTION(ctypes.Structure):
	"""Distorsion."""
	_fields_ = [
		("fDrive", ctypes.c_float), ("fDryMix", ctypes.c_float),
		("fWetMix", ctypes.c_float), ("fFeedback", ctypes.c_float),
		("fVolume", ctypes.c_float), ("lChannel", ctypes.c_int),
	]

class BASS_BFX_COMPRESSOR2(ctypes.Structure):
	"""Compresor 2."""
	_fields_ = [
		("fGain", ctypes.c_float), ("fThreshold", ctypes.c_float),
		("fRatio", ctypes.c_float), ("fAttack", ctypes.c_float),
		("fRelease", ctypes.c_float), ("lChannel", ctypes.c_int),
	]

class BASS_BFX_ENV_NODE(ctypes.Structure):
	"""Nodo de envolvente de volumen."""
	_fields_ = [("pos", ctypes.c_long), ("val", ctypes.c_float)]

class BASS_BFX_VOLUME_ENV(ctypes.Structure):
	"""Envolvente de volumen."""
	_fields_ = [
		("lChannel", ctypes.c_int), ("lNodeCount", ctypes.c_int),
		("pNodes", ctypes.POINTER(BASS_BFX_ENV_NODE)), ("bFollow", ctypes.c_int),
	]

class BASS_BFX_BQF(ctypes.Structure):
	"""Filtro BiQuad."""
	_fields_ = [
		("lFilter", ctypes.c_int), ("fCenter", ctypes.c_float),
		("fGain", ctypes.c_float), ("fBandwidth", ctypes.c_float),
		("fQ", ctypes.c_float), ("fS", ctypes.c_float),
		("lChannel", ctypes.c_int),
	]


# ─── BASSmix ─────────────────────────────────────────────────────────

class BASS_MIXER_NODE(ctypes.Structure):
	"""Nodo de envolvente del mezclador."""
	_fields_ = [("pos", ctypes.c_int64), ("value", ctypes.c_float)]


# ─── BASSMIDI ────────────────────────────────────────────────────────

HSOUNDFONT = ctypes.c_ulong

class BASS_MIDI_FONT(ctypes.Structure):
	"""Asignacion de soundfont a preset/banco."""
	_fields_ = [("font", HSOUNDFONT), ("preset", ctypes.c_int), ("bank", ctypes.c_int)]

class BASS_MIDI_FONTEX(ctypes.Structure):
	"""Asignacion extendida de soundfont."""
	_fields_ = [
		("font", HSOUNDFONT), ("spreset", ctypes.c_int), ("sbank", ctypes.c_int),
		("dpreset", ctypes.c_int), ("dbank", ctypes.c_int), ("dbanklsb", ctypes.c_int),
	]

class BASS_MIDI_FONTEX2(ctypes.Structure):
	"""Asignacion extendida 2 de soundfont."""
	_fields_ = [
		("font", HSOUNDFONT), ("spreset", ctypes.c_int), ("sbank", ctypes.c_int),
		("dpreset", ctypes.c_int), ("dbank", ctypes.c_int), ("dbanklsb", ctypes.c_int),
		("mkey", ctypes.c_int), ("mkeyv", ctypes.c_int),
	]

class BASS_MIDI_FONTINFO(ctypes.Structure):
	"""Informacion de un soundfont."""
	_fields_ = [
		("name", ctypes.c_char_p), ("copyright", ctypes.c_char_p),
		("comment", ctypes.c_char_p), ("presets", ctypes.c_ulong),
		("samsize", ctypes.c_ulong), ("samload", ctypes.c_ulong),
		("samtype", ctypes.c_ulong),
	]

class BASS_MIDI_MARK(ctypes.Structure):
	"""Marcador MIDI."""
	_fields_ = [("track", ctypes.c_ulong), ("pos", ctypes.c_ulong), ("text", ctypes.c_char_p)]

class BASS_MIDI_EVENT(ctypes.Structure):
	"""Evento MIDI."""
	_fields_ = [
		("event", ctypes.c_ulong), ("param", ctypes.c_ulong),
		("chan", ctypes.c_ulong), ("tick", ctypes.c_ulong), ("pos", ctypes.c_ulong),
	]

class BASS_MIDI_DEVICEINFO(ctypes.Structure):
	"""Informacion de dispositivo MIDI de entrada."""
	_fields_ = [("name", ctypes.c_char_p), ("id", ctypes.c_ulong), ("flags", ctypes.c_ulong)]


# ─── BASSWASAPI ──────────────────────────────────────────────────────

class BASS_WASAPI_DEVICEINFO(ctypes.Structure):
	"""Informacion de dispositivo WASAPI."""
	_fields_ = [
		("name", ctypes.c_char_p), ("id", ctypes.c_char_p),
		("type", ctypes.c_ulong), ("flags", ctypes.c_ulong),
		("minperiod", ctypes.c_float), ("defperiod", ctypes.c_float),
		("mixfreq", ctypes.c_ulong), ("mixchans", ctypes.c_ulong),
	]

class BASS_WASAPI_INFO(ctypes.Structure):
	"""Informacion del dispositivo WASAPI inicializado."""
	_fields_ = [
		("initflag", ctypes.c_ulong), ("freq", ctypes.c_ulong),
		("chans", ctypes.c_ulong), ("format", ctypes.c_ulong),
		("buflen", ctypes.c_ulong), ("volmax", ctypes.c_float),
		("volmin", ctypes.c_float), ("volstep", ctypes.c_float),
	]


# ─── BASSWMA ─────────────────────────────────────────────────────────

HWMENCODE = ctypes.c_ulong


# ─── BASSCD ──────────────────────────────────────────────────────────

class BASS_CD_INFO(ctypes.Structure):
	"""Informacion de una unidad de CD."""
	_fields_ = [
		("vendor", ctypes.c_char_p), ("product", ctypes.c_char_p),
		("rev", ctypes.c_char_p), ("letter", ctypes.c_int),
		("rwflags", ctypes.c_ulong), ("canopen", ctypes.c_int),
		("canlock", ctypes.c_int), ("maxspeed", ctypes.c_ulong),
		("cache", ctypes.c_ulong), ("cdtext", ctypes.c_int),
	]

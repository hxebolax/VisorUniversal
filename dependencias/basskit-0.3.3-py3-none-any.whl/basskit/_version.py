# -*- coding: utf-8 -*-
"""Version de basskit."""
__version__ = "0.3.3"

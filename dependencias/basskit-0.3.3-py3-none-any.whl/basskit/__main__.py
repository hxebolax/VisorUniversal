# -*- coding: utf-8 -*-
"""Punto de entrada CLI para basskit."""

from basskit.herramientas.diagnostico import imprimir_diagnostico

if __name__ == "__main__":
	imprimir_diagnostico()

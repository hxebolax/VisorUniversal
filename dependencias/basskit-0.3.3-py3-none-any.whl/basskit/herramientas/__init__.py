# -*- coding: utf-8 -*-
"""Paquete de herramientas de basskit."""

from .diagnostico import diagnostico, imprimir_diagnostico

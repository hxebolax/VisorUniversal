# -*- coding: utf-8 -*-
"""Callbacks de todos los add-ons de BASS."""

import ctypes

BASSCALLBACK = ctypes.WINFUNCTYPE

# ─── BASS_FX ─────────────────────────────────────────────────────────
BPMPROCESSPROC = BASSCALLBACK(None, ctypes.c_ulong, ctypes.c_float)
BPMPROC = BASSCALLBACK(None, ctypes.c_ulong, ctypes.c_float, ctypes.c_void_p)
BPMBEATPROC = BASSCALLBACK(None, ctypes.c_ulong, ctypes.c_double, ctypes.c_void_p)

# ─── BASSenc ─────────────────────────────────────────────────────────
HENCODE = ctypes.c_ulong
ENCODEPROC = BASSCALLBACK(None, HENCODE, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p)
ENCODEPROCEX = BASSCALLBACK(None, HENCODE, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong, ctypes.c_int64, ctypes.c_void_p)
ENCODECLIENTPROC = BASSCALLBACK(ctypes.c_int, HENCODE, ctypes.c_int, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_void_p)
ENCODENOTIFYPROC = BASSCALLBACK(None, HENCODE, ctypes.c_ulong, ctypes.c_void_p)
ENCODERPROC = BASSCALLBACK(ctypes.c_int, HENCODE, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p)

# ─── BASSWASAPI ──────────────────────────────────────────────────────
WASAPIPROC = BASSCALLBACK(ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p)
WASAPINOTIFYPROC = BASSCALLBACK(None, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_void_p)

# ─── BASSWMA ─────────────────────────────────────────────────────────
HWMENCODE = ctypes.c_ulong
CLIENTCONNECTPROC = BASSCALLBACK(None, HWMENCODE, ctypes.c_int, ctypes.c_char_p, ctypes.c_void_p)
WMENCODEPROC = BASSCALLBACK(None, HWMENCODE, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p)

# ─── BASSMIDI ────────────────────────────────────────────────────────
MIDIINPROC = BASSCALLBACK(None, ctypes.c_ulong, ctypes.c_double, ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p)
MIDIFILTERPROC = BASSCALLBACK(ctypes.c_int, ctypes.c_ulong, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_ulong, ctypes.c_void_p)

# ─── BASSCD ──────────────────────────────────────────────────────────
CDDATAPROC = BASSCALLBACK(None, ctypes.c_ulong, ctypes.c_int, ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p)

# ─── BASSloud ────────────────────────────────────────────────────────
# (No tiene callbacks propios)

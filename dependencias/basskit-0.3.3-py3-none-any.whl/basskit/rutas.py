# -*- coding: utf-8 -*-
"""
Gestión de rutas para localizar las DLL de BASS.

Este módulo resuelve la ubicación del directorio de DLL x64
tanto en modo desarrollo como en instalación desde wheel.
"""

import os
import sys
from pathlib import Path


def obtener_directorio_paquete() -> Path:
	"""
	Devuelve la ruta raíz del paquete basskit instalado.

	Retorna:
		Path al directorio del paquete basskit.
	"""
	return Path(__file__).resolve().parent


def obtener_directorio_dlls() -> Path:
	"""
	Devuelve la ruta al directorio de DLL x64.

	Busca en el siguiente orden:
		1. data/dlls/x64 dentro del paquete instalado.
		2. Variable de entorno BASSKIT_DLL_PATH si está definida.

	Retorna:
		Path al directorio que contiene las DLL x64.

	Lanza:
		FileNotFoundError: Si no se encuentra el directorio de DLL.
	"""
	# Primero: directorio empaquetado dentro del paquete
	ruta_paquete = obtener_directorio_paquete() / "data" / "dlls" / "x64"
	if ruta_paquete.is_dir():
		return ruta_paquete

	# Segundo: variable de entorno
	ruta_env = os.environ.get("BASSKIT_DLL_PATH", "")
	if ruta_env:
		ruta_personalizada = Path(ruta_env)
		if ruta_personalizada.is_dir():
			return ruta_personalizada

	raise FileNotFoundError(
		f"No se encontró el directorio de DLL x64.\n"
		f"Se buscó en: {ruta_paquete}\n"
		f"Puede definir BASSKIT_DLL_PATH como variable de entorno."
	)


def listar_dlls_disponibles() -> list[Path]:
	"""
	Lista todas las DLL disponibles en el directorio x64.

	Retorna:
		Lista de rutas a archivos .dll encontrados.
	"""
	try:
		directorio = obtener_directorio_dlls()
	except FileNotFoundError:
		return []

	return sorted(directorio.glob("*.dll"))


def registrar_directorio_dlls() -> Path | None:
	"""
	Registra el directorio de DLL usando os.add_dll_directory.

	Esto es necesario en Windows 10+ con Python 3.8+ para que
	ctypes pueda encontrar las DLL y sus dependencias.

	Retorna:
		Path al directorio registrado, o None si no se pudo.
	"""
	try:
		directorio = obtener_directorio_dlls()
	except FileNotFoundError:
		return None

	# os.add_dll_directory disponible desde Python 3.8
	if hasattr(os, "add_dll_directory"):
		os.add_dll_directory(str(directorio))

	return directorio

# -*- coding: utf-8 -*-
"""
basskit - Biblioteca Python para BASS Audio Library.

Wrapper completo para BASS y sus add-ons de Un4seen.
Solo Windows 64 bits. Python 3.13+.

Las DLL de BASS y sus add-ons pertenecen a Un4seen Developments Ltd.
El usuario debe respetar sus condiciones de licencia.

Uso rápido:
	import basskit
	info = basskit.diagnostico()
	print(info)
"""

from ._version import __version__
from .herramientas.diagnostico import diagnostico, imprimir_diagnostico
from .excepciones import (
	BassKitError,
	ErrorDLLNoEncontrada,
	ErrorArquitecturaInvalida,
	ErrorVersionPython,
	ErrorFuncionNoEncontrada,
	ErrorBassNativo,
)

__all__ = [
	"__version__",
	"diagnostico",
	"imprimir_diagnostico",
	"BassKitError",
	"ErrorDLLNoEncontrada",
	"ErrorArquitecturaInvalida",
	"ErrorVersionPython",
	"ErrorFuncionNoEncontrada",
	"ErrorBassNativo",
]

# -*- coding: utf-8 -*-
"""Bindings de bajo nivel para basswma.dll. Soporte WMA."""

import ctypes
from typing import Optional
from ..cargador import cargar_addon
from ..tipos import QWORD
from ..callbacks.bass import BASS_FILEPROCS
from ..callbacks.addons import CLIENTCONNECTPROC, WMENCODEPROC, HWMENCODE

_dll: Optional[ctypes.WinDLL] = None

def _obtener() -> ctypes.WinDLL:
	global _dll
	if _dll is None:
		_dll = cargar_addon("basswma")
		if _dll is None:
			raise OSError("basswma.dll no disponible")
		_configurar(_dll)
	return _dll

def _configurar(d: ctypes.WinDLL) -> None:
	d.BASS_WMA_StreamCreateFile.argtypes = [ctypes.c_int, ctypes.c_void_p, QWORD, QWORD, ctypes.c_ulong]
	d.BASS_WMA_StreamCreateFile.restype = ctypes.c_ulong
	d.BASS_WMA_StreamCreateFileAuth.argtypes = [ctypes.c_int, ctypes.c_void_p, QWORD, QWORD, ctypes.c_ulong, ctypes.c_char_p, ctypes.c_char_p]
	d.BASS_WMA_StreamCreateFileAuth.restype = ctypes.c_ulong
	d.BASS_WMA_StreamCreateFileUser.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.POINTER(BASS_FILEPROCS), ctypes.c_void_p]
	d.BASS_WMA_StreamCreateFileUser.restype = ctypes.c_ulong
	d.BASS_WMA_GetTags.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
	d.BASS_WMA_GetTags.restype = ctypes.c_char_p
	d.BASS_WMA_EncodeGetRates.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong]
	d.BASS_WMA_EncodeGetRates.restype = ctypes.POINTER(ctypes.c_ulong)
	d.BASS_WMA_EncodeOpen.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, WMENCODEPROC, ctypes.c_void_p]
	d.BASS_WMA_EncodeOpen.restype = HWMENCODE
	d.BASS_WMA_EncodeOpenFile.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_char_p]
	d.BASS_WMA_EncodeOpenFile.restype = HWMENCODE
	d.BASS_WMA_EncodeOpenNetwork.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong]
	d.BASS_WMA_EncodeOpenNetwork.restype = HWMENCODE
	d.BASS_WMA_EncodeOpenNetworkMulti.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong), ctypes.c_ulong, ctypes.c_ulong]
	d.BASS_WMA_EncodeOpenNetworkMulti.restype = HWMENCODE
	d.BASS_WMA_EncodeOpenPublish.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
	d.BASS_WMA_EncodeOpenPublish.restype = HWMENCODE
	d.BASS_WMA_EncodeOpenPublishMulti.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong), ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
	d.BASS_WMA_EncodeOpenPublishMulti.restype = HWMENCODE
	d.BASS_WMA_EncodeGetPort.argtypes = [HWMENCODE]
	d.BASS_WMA_EncodeGetPort.restype = ctypes.c_ulong
	d.BASS_WMA_EncodeSetNotify.argtypes = [HWMENCODE, CLIENTCONNECTPROC, ctypes.c_void_p]
	d.BASS_WMA_EncodeSetNotify.restype = ctypes.c_int
	d.BASS_WMA_EncodeGetClients.argtypes = [HWMENCODE]
	d.BASS_WMA_EncodeGetClients.restype = ctypes.c_ulong
	d.BASS_WMA_EncodeSetTag.argtypes = [HWMENCODE, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_ulong]
	d.BASS_WMA_EncodeSetTag.restype = ctypes.c_int
	d.BASS_WMA_EncodeWrite.argtypes = [HWMENCODE, ctypes.c_void_p, ctypes.c_ulong]
	d.BASS_WMA_EncodeWrite.restype = ctypes.c_int
	d.BASS_WMA_EncodeClose.argtypes = [HWMENCODE]
	d.BASS_WMA_EncodeClose.restype = ctypes.c_int
	d.BASS_WMA_GetWMObject.argtypes = [ctypes.c_ulong]
	d.BASS_WMA_GetWMObject.restype = ctypes.c_void_p

class BassWmaAPI:
	def __getattr__(self, nombre: str):
		return getattr(_obtener(), nombre)

basswma = BassWmaAPI()

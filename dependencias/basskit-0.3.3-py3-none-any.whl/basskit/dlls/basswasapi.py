# -*- coding: utf-8 -*-
"""Bindings de bajo nivel para basswasapi.dll."""

import ctypes
from typing import Optional
from ..cargador import cargar_addon
from ..estructuras.addons import BASS_WASAPI_DEVICEINFO, BASS_WASAPI_INFO
from ..callbacks.addons import WASAPIPROC, WASAPINOTIFYPROC

_dll: Optional[ctypes.WinDLL] = None

def _obtener() -> ctypes.WinDLL:
	global _dll
	if _dll is None:
		_dll = cargar_addon("basswasapi")
		if _dll is None:
			raise OSError("basswasapi.dll no disponible")
		_configurar(_dll)
	return _dll

def _configurar(d: ctypes.WinDLL) -> None:
	d.BASS_WASAPI_GetVersion.argtypes = []
	d.BASS_WASAPI_GetVersion.restype = ctypes.c_ulong
	d.BASS_WASAPI_SetNotify.argtypes = [WASAPINOTIFYPROC, ctypes.c_void_p]
	d.BASS_WASAPI_SetNotify.restype = ctypes.c_int
	d.BASS_WASAPI_GetDeviceInfo.argtypes = [ctypes.c_ulong, ctypes.POINTER(BASS_WASAPI_DEVICEINFO)]
	d.BASS_WASAPI_GetDeviceInfo.restype = ctypes.c_int
	d.BASS_WASAPI_GetDeviceLevel.argtypes = [ctypes.c_ulong, ctypes.c_int]
	d.BASS_WASAPI_GetDeviceLevel.restype = ctypes.c_float
	d.BASS_WASAPI_SetDevice.argtypes = [ctypes.c_ulong]
	d.BASS_WASAPI_SetDevice.restype = ctypes.c_int
	d.BASS_WASAPI_GetDevice.argtypes = []
	d.BASS_WASAPI_GetDevice.restype = ctypes.c_ulong
	d.BASS_WASAPI_CheckFormat.argtypes = [ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong]
	d.BASS_WASAPI_CheckFormat.restype = ctypes.c_ulong
	d.BASS_WASAPI_Init.argtypes = [ctypes.c_int, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_float, ctypes.c_float, WASAPIPROC, ctypes.c_void_p]
	d.BASS_WASAPI_Init.restype = ctypes.c_int
	d.BASS_WASAPI_Free.argtypes = []
	d.BASS_WASAPI_Free.restype = ctypes.c_int
	d.BASS_WASAPI_GetInfo.argtypes = [ctypes.POINTER(BASS_WASAPI_INFO)]
	d.BASS_WASAPI_GetInfo.restype = ctypes.c_int
	d.BASS_WASAPI_GetCPU.argtypes = []
	d.BASS_WASAPI_GetCPU.restype = ctypes.c_float
	d.BASS_WASAPI_Lock.argtypes = [ctypes.c_int]
	d.BASS_WASAPI_Lock.restype = ctypes.c_int
	d.BASS_WASAPI_Start.argtypes = []
	d.BASS_WASAPI_Start.restype = ctypes.c_int
	d.BASS_WASAPI_Stop.argtypes = [ctypes.c_int]
	d.BASS_WASAPI_Stop.restype = ctypes.c_int
	d.BASS_WASAPI_IsStarted.argtypes = []
	d.BASS_WASAPI_IsStarted.restype = ctypes.c_ulong
	d.BASS_WASAPI_SetVolume.argtypes = [ctypes.c_ulong, ctypes.c_float]
	d.BASS_WASAPI_SetVolume.restype = ctypes.c_int
	d.BASS_WASAPI_GetVolume.argtypes = [ctypes.c_ulong]
	d.BASS_WASAPI_GetVolume.restype = ctypes.c_float
	d.BASS_WASAPI_SetMute.argtypes = [ctypes.c_int]
	d.BASS_WASAPI_SetMute.restype = ctypes.c_int
	d.BASS_WASAPI_GetMute.argtypes = []
	d.BASS_WASAPI_GetMute.restype = ctypes.c_int
	d.BASS_WASAPI_PutData.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
	d.BASS_WASAPI_PutData.restype = ctypes.c_ulong
	d.BASS_WASAPI_GetData.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
	d.BASS_WASAPI_GetData.restype = ctypes.c_ulong
	d.BASS_WASAPI_GetLevel.argtypes = []
	d.BASS_WASAPI_GetLevel.restype = ctypes.c_ulong

class BassWasapiAPI:
	def __getattr__(self, nombre: str):
		return getattr(_obtener(), nombre)

basswasapi = BassWasapiAPI()

# -*- coding: utf-8 -*-
"""
Bindings de bajo nivel para bass_fx.dll.

Efectos DSP avanzados, tempo/pitch, reverse y deteccion BPM.
"""

import ctypes
from typing import Optional
from ..cargador import cargar_addon
from ..callbacks.addons import BPMPROCESSPROC, BPMPROC, BPMBEATPROC

_dll: Optional[ctypes.WinDLL] = None

def _obtener() -> ctypes.WinDLL:
	global _dll
	if _dll is None:
		_dll = cargar_addon("bass_fx")
		if _dll is None:
			raise OSError("bass_fx.dll no disponible")
		_configurar(_dll)
	return _dll

def _configurar(d: ctypes.WinDLL) -> None:
	d.BASS_FX_GetVersion.argtypes = []
	d.BASS_FX_GetVersion.restype = ctypes.c_ulong

	d.BASS_FX_TempoCreate.argtypes = [ctypes.c_ulong, ctypes.c_ulong]
	d.BASS_FX_TempoCreate.restype = ctypes.c_ulong

	d.BASS_FX_TempoGetSource.argtypes = [ctypes.c_ulong]
	d.BASS_FX_TempoGetSource.restype = ctypes.c_ulong

	d.BASS_FX_TempoGetRateRatio.argtypes = [ctypes.c_ulong]
	d.BASS_FX_TempoGetRateRatio.restype = ctypes.c_float

	d.BASS_FX_ReverseCreate.argtypes = [ctypes.c_ulong, ctypes.c_float, ctypes.c_ulong]
	d.BASS_FX_ReverseCreate.restype = ctypes.c_ulong

	d.BASS_FX_ReverseGetSource.argtypes = [ctypes.c_ulong]
	d.BASS_FX_ReverseGetSource.restype = ctypes.c_ulong

	d.BASS_FX_BPM_DecodeGet.argtypes = [ctypes.c_ulong, ctypes.c_double, ctypes.c_double, ctypes.c_ulong, ctypes.c_ulong, BPMPROCESSPROC]
	d.BASS_FX_BPM_DecodeGet.restype = ctypes.c_float

	d.BASS_FX_BPM_CallbackSet.argtypes = [ctypes.c_ulong, BPMPROC, ctypes.c_double, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_void_p]
	d.BASS_FX_BPM_CallbackSet.restype = ctypes.c_int

	d.BASS_FX_BPM_CallbackReset.argtypes = [ctypes.c_ulong]
	d.BASS_FX_BPM_CallbackReset.restype = ctypes.c_int

	d.BASS_FX_BPM_Translate.argtypes = [ctypes.c_ulong, ctypes.c_float, ctypes.c_ulong]
	d.BASS_FX_BPM_Translate.restype = ctypes.c_float

	d.BASS_FX_BPM_Free.argtypes = [ctypes.c_ulong]
	d.BASS_FX_BPM_Free.restype = ctypes.c_int

	d.BASS_FX_BPM_BeatCallbackSet.argtypes = [ctypes.c_ulong, BPMBEATPROC, ctypes.c_void_p]
	d.BASS_FX_BPM_BeatCallbackSet.restype = ctypes.c_int

	d.BASS_FX_BPM_BeatCallbackReset.argtypes = [ctypes.c_ulong]
	d.BASS_FX_BPM_BeatCallbackReset.restype = ctypes.c_int

	d.BASS_FX_BPM_BeatDecodeGet.argtypes = [ctypes.c_ulong, ctypes.c_double, ctypes.c_double, ctypes.c_ulong, BPMBEATPROC, ctypes.c_void_p]
	d.BASS_FX_BPM_BeatDecodeGet.restype = ctypes.c_int

	d.BASS_FX_BPM_BeatSetParameters.argtypes = [ctypes.c_ulong, ctypes.c_float, ctypes.c_float, ctypes.c_float]
	d.BASS_FX_BPM_BeatSetParameters.restype = ctypes.c_int

	d.BASS_FX_BPM_BeatGetParameters.argtypes = [ctypes.c_ulong, ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float)]
	d.BASS_FX_BPM_BeatGetParameters.restype = ctypes.c_int

	d.BASS_FX_BPM_BeatFree.argtypes = [ctypes.c_ulong]
	d.BASS_FX_BPM_BeatFree.restype = ctypes.c_int

class BassFXAPI:
	"""Proxy de acceso a bass_fx.dll."""
	def __getattr__(self, nombre: str):
		return getattr(_obtener(), nombre)

bass_fx = BassFXAPI()
